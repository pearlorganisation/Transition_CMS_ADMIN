import React from "react";

const EditTeam = () => {
  return <div>EditTeam</div>;
};

export default EditTeam;
