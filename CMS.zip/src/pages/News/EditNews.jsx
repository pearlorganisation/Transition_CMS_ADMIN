import React from "react";

const EditNews = () => {
  return <div>EditNews</div>;
};

export default EditNews;
